import java.util.ArrayList;
import java.util.List;

public class Forest {
    private final List<Tree> trees;

    public Forest() {
        trees = new ArrayList<>();
    }

    public void addTree(int growthPct){
        trees.add(new Tree(growthPct));
    }

    public String toString() {  
        StringBuilder result = new StringBuilder("Forest(");
        for (Tree tree : trees) {
            result.append(tree.toString());
        }
        result.append(")");
        return result.toString();
    }

// Prefer StringBuilder when you are concatinating in a loop

    public void growOneYear() {
//        for (int i = 0; i < trees.size(); i++) {
//           trees.get(i).growOneYear();
//        }

        for (Tree tree : trees) {
            tree.growOneYear();
        }

    }
}
