import java.util.ArrayList;

public class Shops {
    private final ArrayList<IceCreamShop> shops;

    public Shops() {
        shops = new ArrayList<>();
    }

    public ArrayList<IceCreamShop> getIceCreamShops() {
        return shops;
    }

    public void addShop(IceCreamShop iceCreamShop) {
        if (!shops.contains(iceCreamShop)) {
            shops.add(iceCreamShop);
        }
    }

    public void removeShop(IceCreamShop iceCreamShop) {
        shops.remove(iceCreamShop);
    }

    public int amountOfShops() {
        return shops.size();
    }

    public ArrayList<IceCreamShop> shopsWithFlavour(String flavour) {
        ArrayList<IceCreamShop> shops2 = new ArrayList<>();
        for (IceCreamShop iceCreamShop : shops) {
            if ((iceCreamShop.getVariants()).contains(flavour)) {
                shops2.add(iceCreamShop);
            }
        }
        return shops2;
    }

    public void printShops (String flavour){
        if (shopsWithFlavour(flavour).isEmpty()){
            System.out.println("Oh no, there are no shops with the " +  flavour + " variant");
        } else {
            System.out.println("These are the shops that have the " + flavour + " variant: ");
            for (IceCreamShop iceCreamShop : shopsWithFlavour(flavour)) {
                System.out.println(iceCreamShop.getName());
            }
        }
    }
}



/*
import java.util.ArrayList;

public class Shops {
    ArrayList<IceCreamShop> iceCreamShops;

    public Shops() {
        iceCreamShops = new ArrayList<>();
    }

    public ArrayList<IceCreamShop> getIceCreamShops() {
        return iceCreamShops;
    }

    public void addShop(IceCreamShop name) {
        if(!iceCreamShops.contains(name)) {
            iceCreamShops.add(name);
        }
    }

    public void removeShop(IceCreamShop name) {
        if(iceCreamShops.contains(name)) {
            iceCreamShops.remove(name);
        }
    }

    public int amountOfShops() {
        return iceCreamShops.size();
    }

    public ArrayList<IceCreamShop> shopsWithFlavour(String flavour) {
        ArrayList<IceCreamShop> flavourShops = new ArrayList<>();

        for (IceCreamShop shop : iceCreamShops) {
            if(shop.getVariants().contains(flavour)) {
                flavourShops.add(shop);
            }
        }
        return flavourShops;
    }

    public void printShops(String flavour) {

        if(shopsWithFlavour(flavour).isEmpty()) {
            System.out.println("Oh no, there are no shops with the " + flavour + " variant");
        }
        else {
            String line = "These are the shops that have the " + flavour + " variant:";
            System.out.println(line);

            for(IceCreamShop shop : shopsWithFlavour(flavour)) {
                System.out.println(shop.getName());
            }
        }
    }
}*/
