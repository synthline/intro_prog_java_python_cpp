import java.util.ArrayList;

public class IceCreamShop {
    private final String shopName;
    private final ArrayList<String> icecreamVariants;

    public IceCreamShop(String shopName) {
        this.shopName = shopName;
        icecreamVariants = new ArrayList<>();
    }

    public String getName() {
        return shopName;
    }

    public ArrayList<String> getVariants() {
        return icecreamVariants;
    }

    public void addFlavours(String flavour) {
        if (!icecreamVariants.contains(flavour)) {
            icecreamVariants.add(flavour);
        }
    }

    public void removeFlavours(String flavour) {
        icecreamVariants.remove(flavour);
    }

    public int amountOfVariants() {
        return icecreamVariants.size();
    }

    public void printFlavours() {
        System.out.println(shopName + " has " + amountOfVariants() + " different flavours:");
        for (String flavour : icecreamVariants) {
            System.out.println(flavour);
        }
    }

    public static void main(String[] args) {
        IceCreamShop n1 = new IceCreamShop("7/11");
        n1.addFlavours("Chocolate");
        n1.addFlavours("Chocolate");
        n1.addFlavours("Vanilla");
        System.out.println(n1.amountOfVariants());
        n1.addFlavours("Strawberry");
        n1.removeFlavours("Vanilla");
        System.out.println(n1.amountOfVariants());
        System.out.println(n1.amountOfVariants());
        System.out.println(n1.getName());
        System.out.println(n1.getVariants());
    }
}

/*
import java.util.ArrayList;

public class IceCreamShop {
    private String shopName;
    private ArrayList<String> variants;

    public IceCreamShop(String shopName) {
        this.shopName = shopName;
        variants = new ArrayList<>();
    }

    public String getName() {
        return shopName;
    }

    public ArrayList<String> getVariants() {
        return variants;
    }

    public void addFlavours(String flavour) {
        if(!variants.contains(flavour)) {
            variants.add(flavour);
        }
    }

    public void removeFlavours(String flavour) {
        if(variants.contains(flavour)) {
            variants.remove(flavour);
        }
    }

    public int amountOfVariants() {
        return variants.size();
    }

    public void printFlavours() {
        String line = shopName + " has " + amountOfVariants() + " different flavours:";
        System.out.println(line);

        for(String flavour : variants) {
            System.out.println(flavour);
        }
    }
}*/
