import java.util.ArrayList;
import java.util.List;

public class Pizza extends Food {
    protected List<String> toppings;

    public Pizza() {
        super("Pizza", 45);
        toppings = new ArrayList<>();
    }

    public void addTopping(String topping) {
        price += 10;
        toppings.add(topping);
    }

    @Override
    public void display() {
        System.out.print(price + " kr " + name + " { ");

        String separator = "";

        for (String topping : toppings) {
            System.out.print(separator);
            System.out.print(topping);
            separator = ", ";
        }
        System.out.println(" }");
    }

    public void setName(String name) {
        this.name = name;
    }
}